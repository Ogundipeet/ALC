package com.example.android.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LayoutActivity extends AppCompatActivity {

    private Button button1, button2, button3, home;
    String e1 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout);

        Intent intent = getIntent();
        e1 = intent.getStringExtra("e1");

        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);

        home = (Button) findViewById(R.id.button4);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openLayout1();
            }
        });



        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(e1 != null && e1.equalsIgnoreCase( "comp")){
                    openLayoutComp();
                }
                else {
                    openLayout();
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(e1 != null && e1.equalsIgnoreCase( "comp")){
                    openLayoutComp2();
                }
                else {
                    openLayout2();
                }
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(e1 != null && e1.equalsIgnoreCase( "comp")){
                    openLayoutComp3();
                }
                else {
                    openLayout3();
                }
            }
        });
    }

    public void openLayout(){
        Intent intent = new Intent(LayoutActivity.this, ThreeByThreeActivity.class);
        intent.putExtra("e1", "");
        startActivity(intent);
    }
    public void openLayoutComp(){
        Intent intent = new Intent(LayoutActivity.this, ThreeByThreeActivity.class);
        intent.putExtra("e1", e1);
        startActivity(intent);
    }

    public void openLayout2(){
        Intent intent = new Intent(LayoutActivity.this, FourByFourActivity.class);
        intent.putExtra("e1", "");
        startActivity(intent);
    }
    public void openLayoutComp2(){
        Intent intent = new Intent(LayoutActivity.this, FourByFourActivity.class);
        intent.putExtra("e1", e1);
        startActivity(intent);
    }

    public void openLayout3(){
        Intent intent = new Intent(LayoutActivity.this, FiveByFiveActivity.class);
        intent.putExtra("e1", "");
        startActivity(intent);
    }
    public void openLayoutComp3(){
        Intent intent = new Intent(LayoutActivity.this, FiveByFiveActivity.class);
        intent.putExtra("e1", e1);
        startActivity(intent);
    }

    public void openLayout1(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
