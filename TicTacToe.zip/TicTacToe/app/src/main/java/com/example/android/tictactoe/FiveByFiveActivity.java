package com.example.android.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FiveByFiveActivity extends AppCompatActivity {

    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, home, reset;
    int turn;

    int scoreX = 0;
    int scoreY = 0;
    String i;
    int count = 0;

    private static Random random = new Random();
    ArrayList<String> list = new ArrayList<>();

    String e1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_five_by_five);

        Intent intent = getIntent();
        e1 = intent.getStringExtra("e1");


        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);
        b5 = (Button) findViewById(R.id.b5);
        b6 = (Button) findViewById(R.id.b6);
        b7 = (Button) findViewById(R.id.b7);
        b8 = (Button) findViewById(R.id.b8);
        b9 = (Button) findViewById(R.id.b9);
        b10 = (Button) findViewById(R.id.b10);
        b11 = (Button) findViewById(R.id.b11);
        b12 = (Button) findViewById(R.id.b12);
        b13 = (Button) findViewById(R.id.b13);
        b14 = (Button) findViewById(R.id.b14);
        b15 = (Button) findViewById(R.id.b15);
        b16 = (Button) findViewById(R.id.b16);
        b17 = (Button) findViewById(R.id.b17);
        b18 = (Button) findViewById(R.id.b18);
        b19 = (Button) findViewById(R.id.b19);
        b20 = (Button) findViewById(R.id.b20);
        b21 = (Button) findViewById(R.id.b21);
        b22 = (Button) findViewById(R.id.b22);
        b23 = (Button) findViewById(R.id.b23);
        b24 = (Button) findViewById(R.id.b24);
        b25 = (Button) findViewById(R.id.b25);

        turn = 1;
        if (e1 != null && e1.equalsIgnoreCase("comp")) {

            list.add("b1");
            list.add("b2");
            list.add("b3");
            list.add("b4");
            list.add("b5");
            list.add("b6");
            list.add("b7");
            list.add("b8");
            list.add("b9");
            list.add("b10");
            list.add("b11");
            list.add("b12");
            list.add("b13");
            list.add("b14");
            list.add("b15");
            list.add("b16");
            list.add("b17");
            list.add("b18");
            list.add("b19");
            list.add("b20");
            list.add("b21");
            list.add("b22");
            list.add("b23");
            list.add("b24");
            list.add("b25");

            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b1.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b1.setText("X");
                            list.remove(0);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }

                }
            });

            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b2.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b2.setText("X");
                            list.remove(1);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b3.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b3.setText("X");
                            list.remove(2);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }

                }
            });

            b4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b4.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b4.setText("X");
                            list.remove(3);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b5.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b5.setText("X");
                            list.remove(4);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b6.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b6.setText("X");
                            list.remove(5);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b7.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b7.setText("X");
                            list.remove(6);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b8.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b8.setText("X");
                            list.remove(7);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b9.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b9.setText("X");
                            list.remove(8);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });


            b10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b10.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b10.setText("X");
                            list.remove(9);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b11.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b11.setText("X");
                            list.remove(10);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b12.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b12.setText("X");
                            list.remove(11);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b13.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b13.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b13.setText("X");
                            list.remove(12);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b14.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b14.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b14.setText("X");
                            list.remove(13);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });


            b15.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b15.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b15.setText("X");
                            list.remove(14);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b16.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b16.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b16.setText("X");
                            list.remove(15);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });
            b17.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b17.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b17.setText("X");
                            list.remove(16);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }

                }
            });

            b18.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b18.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b18.setText("X");
                            list.remove(17);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b19.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b19.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b19.setText("X");
                            list.remove(18);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }

                }
            });

            b20.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b20.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b20.setText("X");
                            list.remove(19);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b21.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b21.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b21.setText("X");
                            list.remove(20);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b22.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b22.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b22.setText("X");
                            list.remove(21);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b23.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b23.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b23.setText("X");
                            list.remove(22);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b24.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b24.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b24.setText("X");
                            list.remove(23);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });

            b25.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b25.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b25.setText("X");
                            list.remove(24);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }

                }
            });



        }
        else {
            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b1.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b1.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b1.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }

                }
            });

            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b2.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b2.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b2.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b3.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b3.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b3.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b4.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b4.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b4.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b5.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b5.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b5.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b6.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b6.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b6.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b7.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b7.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b7.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b8.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b8.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b8.setText("O");
                        }
                        count++;

                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b9.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b9.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b9.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b10.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b10.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b10.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }

                }
            });

            b11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b11.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b11.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b11.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b12.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b12.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b12.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b13.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b13.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b13.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b13.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b14.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b14.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b14.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b14.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b15.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b15.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b15.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b15.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b16.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b16.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b16.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b16.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });
            b17.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b17.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b17.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b17.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }

                }
            });

            b18.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b18.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b18.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b18.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b19.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b19.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b19.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b19.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b20.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b20.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b20.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b20.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b21.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b21.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b21.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b21.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b22.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b22.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b22.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b22.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b23.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b23.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b23.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b23.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b24.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b24.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b24.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b24.setText("O");
                        }
                        count++;

                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b25.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b25.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b25.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b25.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 25) {
                        reset();
                        count = 0;
                    }
                }
            });

        }
        reset = (Button) findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (e1 != null && e1.equalsIgnoreCase("comp")) {
                    list.add("b1");
                    list.add("b2");
                    list.add("b3");
                    list.add("b4");
                    list.add("b5");
                    list.add("b6");
                    list.add("b7");
                    list.add("b8");
                    list.add("b9");
                    list.add("b10");
                    list.add("b11");
                    list.add("b12");
                    list.add("b13");
                    list.add("b14");
                    list.add("b15");
                    list.add("b16");
                    list.add("b17");
                    list.add("b18");
                    list.add("b19");
                    list.add("b20");
                    list.add("b21");
                    list.add("b22");
                    list.add("b23");
                    list.add("b24");
                    list.add("b25");
                }
                b1.setText("");
                b2.setText("");
                b3.setText("");
                b4.setText("");
                b5.setText("");
                b6.setText("");
                b7.setText("");
                b8.setText("");
                b9.setText("");
                b10.setText("");
                b11.setText("");
                b12.setText("");
                b13.setText("");
                b14.setText("");
                b15.setText("");
                b16.setText("");
                b17.setText("");
                b18.setText("");
                b19.setText("");
                b20.setText("");
                b21.setText("");
                b22.setText("");
                b23.setText("");
                b24.setText("");
                b25.setText("");
                scoreY = 0;
                scoreX = 0;
                displayForX(scoreX);
                displayForO(scoreY);
                count = 0;


            }
        });

        home = (Button) findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openLayout();
            }
        });
    }
    public void openLayout() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void doCpu() {
        i = getRandomItem(list);

        if (i.equals("b1")) {
            //b1.performClick();
            b1.setText("O");
            list.remove(0);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }

        }

        if (i.equals("b2")) {

            //b2.performClick();
            b2.setText("O");
            list.remove(1);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b3")) {
            //b3.performClick();
            b3.setText("O");
            list.remove(2);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b4")) {

            b4.setText("O");
            list.remove(3);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b5")) {

            b5.setText("O");
            list.remove(4);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b6")) {

            b6.setText("O");
            list.remove(5);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b7")) {

            b7.setText("O");
            list.remove(6);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b8")) {

            b8.setText("O");
            list.remove(7);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b9")) {

            b9.setText("O");
            list.remove(8);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }
        if (i.equals("b10")) {
            //b1.performClick();
            b10.setText("O");
            list.remove(9);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }

        }

        if (i.equals("b11")) {

            //b2.performClick();
            b11.setText("O");
            list.remove(10);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b12")) {
            //b3.performClick();
            b12.setText("O");
            list.remove(11);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b13")) {

            b13.setText("O");
            list.remove(12);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b14")) {

            b14.setText("O");
            list.remove(13);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b15")) {

            b15.setText("O");
            list.remove(14);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b16")) {

            b16.setText("O");
            list.remove(15);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }
        if (i.equals("b17")) {
            //b1.performClick();
            b17.setText("O");
            list.remove(16);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }

        }

        if (i.equals("b18")) {

            //b2.performClick();
            b18.setText("O");
            list.remove(17);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b19")) {
            //b3.performClick();
            b19.setText("O");
            list.remove(18);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b20")) {

            b20.setText("O");
            list.remove(19);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b21")) {

            b21.setText("O");
            list.remove(20);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b22")) {

            b22.setText("O");
            list.remove(21);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b23")) {

            b23.setText("O");
            list.remove(22);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b24")) {

            b24.setText("O");
            list.remove(23);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }

        if (i.equals("b25")) {

            b25.setText("O");
            list.remove(24);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 25) {
                reset();

            }
        }
    }

    public Boolean endGame(){
        boolean stat = false;
        String a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y;
        a = b1.getText().toString();
        b = b2.getText().toString();
        c = b3.getText().toString();
        d = b4.getText().toString();
        e = b5.getText().toString();

        f = b6.getText().toString();
        g = b7.getText().toString();
        h = b8.getText().toString();
        i = b9.getText().toString();
        j = b10.getText().toString();

        k = b11.getText().toString();
        l = b12.getText().toString();
        m = b13.getText().toString();
        n = b14.getText().toString();
        o = b15.getText().toString();

        p = b16.getText().toString();
        q = b17.getText().toString();
        r = b18.getText().toString();
        s = b19.getText().toString();
        t = b20.getText().toString();

        u = b21.getText().toString();
        v = b22.getText().toString();
        w = b23.getText().toString();
        x = b24.getText().toString();
        y = b25.getText().toString();

        if(a.equals("X") && b.equals("X") && c.equals("X") && d.equals("X") && e.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(a.equals("X") && f.equals("X") && k.equals("X") && p.equals("X") && u.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(a.equals("X") && g.equals("X") && m.equals("X") && s.equals("X") && y.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }

        if(b.equals("X") && g.equals("X") && l.equals("X") && q.equals("X") && v.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(c.equals("X") && h.equals("X") && m.equals("X") && r.equals("X") && w.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(d.equals("X") && i.equals("X") && n.equals("X") && s.equals("X") && x.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(e.equals("X") && j.equals("X") && o.equals("X") && t.equals("X") && y.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(e.equals("X") && i.equals("X") && m.equals("X") && q.equals("X") && u.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }

        if(f.equals("X") && g.equals("X") && h.equals("X") && i.equals("X") && j.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(k.equals("X") && l.equals("X") && m.equals("X") && n.equals("X") && o.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(p.equals("X") && q.equals("X") && r.equals("X") && s.equals("X") && t.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if(u.equals("X") && v.equals("X") && w.equals("X") && x.equals("X") && y.equals("X")){
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }

        //For O
        if(a.equals("O") && b.equals("O") && c.equals("O") && d.equals("O") && e.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(a.equals("O") && f.equals("O") && k.equals("O") && p.equals("O") && u.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(a.equals("O") && g.equals("O") && m.equals("O") && s.equals("O") && y.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }

        if(b.equals("O") && g.equals("O") && l.equals("O") && q.equals("O") && v.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(c.equals("O") && h.equals("O") && m.equals("O") && r.equals("O") && w.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(d.equals("O") && i.equals("O") && n.equals("O") && s.equals("O") && x.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(e.equals("O") && j.equals("O") && o.equals("O") && t.equals("O") && y.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(e.equals("O") && i.equals("O") && m.equals("O") && q.equals("O") && u.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }

        if(f.equals("O") && g.equals("O") && h.equals("O") && i.equals("O") && j.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(k.equals("O") && l.equals("O") && m.equals("O") && n.equals("O") && o.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(p.equals("O") && q.equals("O") && r.equals("O") && s.equals("O") && t.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }
        if(u.equals("O") && v.equals("O") && w.equals("O") && x.equals("O") && y.equals("O")){
            scoreY++;
            displayForO(scoreY);
            stat = true;

            reset();
        }


        return stat;
    }
    public void reset() {
        b1.setText("");
        b2.setText("");
        b3.setText("");
        b4.setText("");
        b5.setText("");
        b6.setText("");
        b7.setText("");
        b8.setText("");
        b9.setText("");
        b10.setText("");
        b11.setText("");
        b12.setText("");
        b13.setText("");
        b14.setText("");
        b15.setText("");
        b16.setText("");
        b17.setText("");
        b18.setText("");
        b19.setText("");
        b20.setText("");
        b21.setText("");
        b22.setText("");
        b23.setText("");
        b24.setText("");
        b25.setText("");
        count = 0;
        list.add("b1");
        list.add("b2");
        list.add("b3");
        list.add("b4");
        list.add("b5");
        list.add("b6");
        list.add("b7");
        list.add("b8");
        list.add("b9");
        list.add("b10");
        list.add("b11");
        list.add("b12");
        list.add("b13");
        list.add("b14");
        list.add("b15");
        list.add("b16");
        list.add("b17");
        list.add("b18");
        list.add("b19");
        list.add("b20");
        list.add("b21");
        list.add("b22");
        list.add("b23");
        list.add("b24");
        list.add("b25");
    }
    public void displayForX(int score) {
        TextView scoreView = (TextView) findViewById(R.id.X_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayForO(int score) {
        TextView scoreView = (TextView) findViewById(R.id.O_score);
        scoreView.setText(String.valueOf(score));
    }
    private static String getRandomItem(List<String> list) {
        int index = random.nextInt(list.size());
        return list.get(index);

    }

}
