package com.example.android.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ThreeByThreeActivity extends AppCompatActivity {

    private static Random random = new Random();
    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, home, reset;
    int turn;
    int scoreX = 0;
    int scoreY = 0;
    String i;
    int count = 0;
    ArrayList<String> list = new ArrayList<>();

    String e1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three_by_three);

        Intent intent = getIntent();
        e1 = intent.getStringExtra("e1");


        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);
        b5 = (Button) findViewById(R.id.b5);
        b6 = (Button) findViewById(R.id.b6);
        b7 = (Button) findViewById(R.id.b7);
        b8 = (Button) findViewById(R.id.b8);
        b9 = (Button) findViewById(R.id.b9);

        turn = 1;
        if (e1 != null && e1.equalsIgnoreCase("comp")) {

            list.add("b1");
            list.add("b2");
            list.add("b3");
            list.add("b4");
            list.add("b5");
            list.add("b6");
            list.add("b7");
            list.add("b8");
            list.add("b9");



            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b1.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b1.setText("X");

                            list.remove(0);


                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }

                }
            });

            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b2.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b2.setText("X");
                            list.remove(1);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }

                    if (turn == 2) {


                       doCpu();

                    }

                }
            });

            b3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b3.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b3.setText("X");
                            list.remove(2);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }
                }
            });

            b4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b4.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b4.setText("X");
                            list.remove(3);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }
                }
            });

            b5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b5.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b5.setText("X");
                            list.remove(4);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }
                }
            });

            b6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b6.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b6.setText("X");
                            list.remove(5);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();
                    }
                }
            });

            b7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b7.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b7.setText("X");
                            list.remove(6);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }
                }
            });

            b8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b8.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b8.setText("X");
                            list.remove(7);
                        }
                        count++;

                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }
                }
            });

            b9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b9.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b9.setText("X");
                            list.remove(8);
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                    if (turn == 2) {

                        doCpu();

                    }

                }
            });


        } else {
            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b1.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b1.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b1.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }

                }
            });

            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b2.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b2.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b2.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b3.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b3.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b3.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b4.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b4.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b4.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b5.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b5.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b5.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b6.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b6.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b6.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b7.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b7.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b7.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b8.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b8.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b8.setText("O");
                        }
                        count++;

                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                }
            });

            b9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (b9.getText().toString().equals("")) {
                        if (turn == 1) {
                            turn = 2;
                            b9.setText("X");
                        } else if (turn == 2) {
                            turn = 1;
                            b9.setText("O");
                        }
                        count++;
                    }
                    endGame();
                    if (endGame().equals(false) && count == 9) {
                        reset();
                        //count = 0;
                    }
                }
            });
        }


        reset = (Button) findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (e1 != null && e1.equalsIgnoreCase("comp")) {
                    list.add("b1");
                    list.add("b2");
                    list.add("b3");
                    list.add("b4");
                    list.add("b5");
                    list.add("b6");
                    list.add("b7");
                    list.add("b8");
                    list.add("b9");
                }
                b1.setText("");
                b2.setText("");
                b3.setText("");
                b4.setText("");
                b5.setText("");
                b6.setText("");
                b7.setText("");
                b8.setText("");
                b9.setText("");
                scoreY = 0;
                scoreX = 0;
                displayForX(scoreX);
                displayForO(scoreY);
                count = 0;


            }
        });

        home = (Button) findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openLayout();
            }
        });

    }

    public void openLayout() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void doCpu(){
        i = getRandomItem(list);

        if (i.equals("b1")) {
            //b1.performClick();
            b1.setText("O");
            list.remove(0);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }

        }

        if (i.equals("b2")) {

            //b2.performClick();
            b2.setText("O");
            list.remove(1);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }
        }

        if (i.equals("b3")) {
            //b3.performClick();
            b3.setText("O");
            list.remove(2);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }
        }

        if (i.equals("b4")) {

            b4.setText("O");
            list.remove(3);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }
        }

        if (i.equals("b5")) {

            b5.setText("O");
            list.remove(4);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }
        }

        if (i.equals("b6")) {

            b6.setText("O");
            list.remove(5);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }
        }

        if (i.equals("b7")) {

            b7.setText("O");
            list.remove(6);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }
        }

        if (i.equals("b8")) {

            b8.setText("O");
            list.remove(7);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }
        }

        if (i.equals("b9")) {

            b9.setText("O");
            list.remove(8);
            turn = 1;
            count++;
            endGame();
            if (endGame().equals(false) && count == 9) {
                reset();

            }
        }

    }
    public Boolean endGame() {
        boolean stat = false;
        String a, b, c, d, e, f, g, h, i;
        a = b1.getText().toString();
        b = b2.getText().toString();
        c = b3.getText().toString();
        d = b4.getText().toString();
        e = b5.getText().toString();
        f = b6.getText().toString();
        g = b7.getText().toString();
        h = b8.getText().toString();
        i = b9.getText().toString();

        if (a.equals("X") && b.equals("X") && c.equals("X")) {
            scoreX++;
            displayForX(scoreX);
            stat = true;

            reset();
        }
        if (a.equals("X") && d.equals("X") && g.equals("X")) {
            scoreX++;
            displayForX(scoreX);
            stat = true;
            reset();
        }
        if (a.equals("X") && e.equals("X") && i.equals("X")) {
            scoreX++;
            displayForX(scoreX);
            stat = true;
            reset();
        }


        if (b.equals("X") && e.equals("X") && h.equals("X")) {
            scoreX++;
            displayForX(scoreX);
            stat = true;
            reset();
        }

        if (c.equals("X") && f.equals("X") && i.equals("X")) {
            scoreX++;
            displayForX(scoreX);
            stat = true;
            reset();
        }
        if (c.equals("X") && e.equals("X") && g.equals("X")) {
            scoreX++;
            displayForX(scoreX);
            stat = true;
            reset();
        }

        if (d.equals("X") && e.equals("X") && f.equals("X")) {
            scoreX++;
            displayForX(scoreX);
            stat = true;
            reset();
        }

        if (g.equals("X") && h.equals("X") && i.equals("X")) {
            scoreX++;
            displayForX(scoreX);
            stat = true;
            reset();
        }

        //For O

        if (a.equals("O") && b.equals("O") && c.equals("O")) {
            scoreY++;
            displayForO(scoreY);
            stat = true;
            reset();
        }
        if (a.equals("O") && d.equals("O") && g.equals("O")) {
            scoreY++;
            displayForO(scoreY);
            stat = true;
            reset();
        }
        if (a.equals("O") && e.equals("O") && i.equals("O")) {
            scoreY++;
            displayForO(scoreY);
            stat = true;
            reset();
        }


        if (b.equals("O") && e.equals("O") && h.equals("O")) {
            scoreY++;
            displayForO(scoreY);
            stat = true;
            reset();
        }

        if (c.equals("O") && f.equals("O") && i.equals("O")) {
            scoreY++;
            displayForO(scoreY);
            stat = true;
            reset();
        }
        if (c.equals("O") && e.equals("O") && g.equals("O")) {
            scoreY++;
            displayForO(scoreY);
            stat = true;
            reset();
        }

        if (d.equals("O") && e.equals("O") && f.equals("O")) {
            scoreY++;
            displayForO(scoreY);
            stat = true;
            reset();
        }

        if (g.equals("O") && h.equals("O") && i.equals("O")) {
            scoreY++;
            displayForO(scoreY);
            stat = true;
            reset();
        }


        return stat;
    }

    public void reset() {
        b1.setText("");
        b2.setText("");
        b3.setText("");
        b4.setText("");
        b5.setText("");
        b6.setText("");
        b7.setText("");
        b8.setText("");
        b9.setText("");
        count = 0;
        list.add("b1");
        list.add("b2");
        list.add("b3");
        list.add("b4");
        list.add("b5");
        list.add("b6");
        list.add("b7");
        list.add("b8");
        list.add("b9");
    }

    public void displayForX(int score) {
        TextView scoreView = (TextView) findViewById(R.id.X_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayForO(int score) {
        TextView scoreView = (TextView) findViewById(R.id.O_score);
        scoreView.setText(String.valueOf(score));
    }

    private static String getRandomItem(List<String> list) {
        int index = random.nextInt(list.size());
        return list.get(index);

    }
}
